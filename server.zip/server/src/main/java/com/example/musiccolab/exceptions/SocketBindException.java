package com.example.musiccolab.exceptions;

public class SocketBindException extends Exception{
    //
}
