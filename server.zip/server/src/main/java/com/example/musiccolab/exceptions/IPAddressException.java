package com.example.musiccolab.exceptions;

public class IPAddressException extends Exception {
    //
}
